// appointments-backend.js
// Backend API for syncing appointments across devices
// Deploy this to Render.com or your preferred hosting service

const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');

// Middleware
app.use(cors());
app.use(express.json());

// Ensure data directory exists
async function ensureDataDir() {
    try {
        await fs.mkdir(DATA_DIR, { recursive: true });
    } catch (error) {
        console.error('Error creating data directory:', error);
    }
}

ensureDataDir();

// Get appointments for a user
app.get('/api/appointments/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const filePath = path.join(DATA_DIR, `${userId}.json`);
        
        try {
            const data = await fs.readFile(filePath, 'utf8');
            res.json(JSON.parse(data));
        } catch (error) {
            // File doesn't exist, return empty appointments
            res.json({ appointments: [] });
        }
    } catch (error) {
        console.error('Error reading appointments:', error);
        res.status(500).json({ error: 'Failed to load appointments' });
    }
});

// Save appointments for a user
app.post('/api/appointments/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const { appointments } = req.body;
        const filePath = path.join(DATA_DIR, `${userId}.json`);
        
        const data = {
            appointments,
            lastUpdated: new Date().toISOString()
        };
        
        await fs.writeFile(filePath, JSON.stringify(data, null, 2));
        res.json({ success: true, message: 'Appointments saved successfully' });
    } catch (error) {
        console.error('Error saving appointments:', error);
        res.status(500).json({ error: 'Failed to save appointments' });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
    console.log(`Appointments API server running on port ${PORT}`);
});

module.exports = app;
