# Appointment Tracker Backend - Deployment Guide

## Overview
This backend enables cross-device synchronization for your appointment tracker. When you add/edit/delete appointments on desktop, they automatically sync to mobile and vice versa.

## Quick Deploy to Render.com (Recommended - Free)

### Step 1: Prepare Your Files
1. Create a new GitHub repository (or use existing)
2. Upload these files:
   - `appointments-backend.js`
   - `package.json`

### Step 2: Deploy on Render
1. Go to https://render.com and sign up (free tier available)
2. Click "New +" → "Web Service"
3. Connect your GitHub repository
4. Configure:
   - **Name**: `kiranregmi-appointments`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free
5. Click "Create Web Service"

### Step 3: Get Your Backend URL
- After deployment completes, copy your service URL
- It will look like: `https://kiranregmi-appointments.onrender.com`

### Step 4: Update Frontend
1. Open `appointments.html`
2. Find line ~485: `const API_BASE_URL = 'https://kiranregmi-backend.onrender.com/api';`
3. Replace with your actual Render URL: `https://YOUR-SERVICE-NAME.onrender.com/api`
4. Save and deploy to Vercel

## Alternative: Deploy to Your Existing Backend

If you already have a Node.js backend on Render:

1. Add the appointments endpoints to your existing `server.js`:
   ```javascript
   // Copy the /api/appointments routes from appointments-backend.js
   ```

2. Update the frontend `API_BASE_URL` to match your backend

## How It Works

### Data Flow:
1. **User adds appointment on mobile** → Saves to backend → Backend returns success
2. **User opens desktop** → Frontend loads from backend → Shows all appointments including mobile ones
3. **Auto-sync every 30 seconds** → Ensures all devices stay up-to-date

### Fallback Mechanism:
- If backend is offline, appointments save to localStorage
- When backend comes back online, data syncs automatically
- You'll never lose data!

## Testing Sync

1. Open appointments page on desktop
2. Add an appointment
3. Open appointments page on mobile
4. Refresh - you should see the appointment!
5. Add another appointment on mobile
6. Check desktop - it should appear within 30 seconds (or refresh immediately)

## Security Note

Currently using a simple user ID (`kiran-regmi`). In production, you'd want:
- User authentication (JWT tokens)
- User-specific data isolation
- API rate limiting

For personal use, the current setup is fine. Your backend URL is not publicly advertised.

## Troubleshooting

### Sync Status Shows "✗ Sync Failed"
- Check if backend URL is correct
- Verify backend is deployed and running (visit `https://your-backend.onrender.com/health`)
- Check browser console for error messages

### Appointments Not Syncing
1. Open browser console (F12)
2. Look for network errors
3. Verify backend URL in frontend code
4. Check Render logs for backend errors

### Backend Sleeping (Free Tier)
- Render free tier sleeps after 15 minutes of inactivity
- First request after sleep takes 30-60 seconds to wake up
- Subsequent requests are fast

## Cost
- **Render Free Tier**: $0/month
  - 750 hours/month (enough for personal use)
  - Sleeps after 15 min inactivity
  - Wakes up automatically on request

## Support
Questions? Check the Render documentation or contact support.
